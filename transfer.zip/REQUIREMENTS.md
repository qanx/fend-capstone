# Project in short:
add and manage your trip . and calcaute dates to remined you about your trip.



useful tips.
1- " npm install " to install all node_modules
2- "npm run mon " to refresh server auto;
3- "npm run build-prod" to create the final dist folder.
4- "npm run build-dev" to run dev mode;



good luck