## make sure to install all requierd packages , cuz I coulding upload them on udacity with zip file.

# "dependencies": 
    "@babel/polyfill": "^7.12.1",
    "babel-jest": "^26.6.3",
    "babel-polyfill": "^6.26.0",
    "cors": "^2.8.5",
    "dotenv": "^8.2.0",
    "express": "^4.17.1",
    "jest-cli": "^26.6.3",
    "node-fetch": "^2.6.1",
    "regenerator-runtime": "^0.13.7",
    "webpack": "^4.46.0",
    "webpack-cli": "^3.3.12"

 #    plugin: 
    workbox-webpack-plugin
    dotenv-webpack
    clean-webpack-plugin
    html-webpack-plugin
    webpack
    path